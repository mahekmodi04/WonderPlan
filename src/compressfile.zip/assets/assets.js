import frontpage from './frontpage.png';
import about1 from './about1.png'
import about2 from './about2.png'
import about3 from './about3.png'
import about4 from './about4.png'

export const assets = {
  frontpage,
  about1,
  about2,
  about3,
  about4,
};
